function abrirt(){
    document.getElementById("vent").style.display="block";
}

function abrird(){
    document.getElementById("ventd").style.display="block";
}

function abrirtar(){
    document.getElementById("ventar").style.display="block";
 console.log("errores")
}

function cerrart(){
    document.getElementById("vent").style.display="none";
}

function cerrard(){
    document.getElementById("ventd").style.display="none";
}

function cerrartar(){
    document.getElementById("ventar").style.display="none";
}